import pandas as pd

SLSQP_08  = pd.read_csv( "df_8_SLSQP.csv")
SLSQP_16  = pd.read_csv("df_16_SLSQP.csv")
SLSQP_24  = pd.read_csv("df_24_SLSQP.csv")
SLSQP_32  = pd.read_csv("df_32_SLSQP.csv")
SLSQP_40  = pd.read_csv("df_40_SLSQP.csv")
SLSQP_48  = pd.read_csv("df_48_SLSQP.csv")
COBYLA_08 = pd.read_csv("df_8_COBYLA.csv")
COBYLA_16 = pd.read_csv("df_16_COBYLA.csv")
COBYLA_24 = pd.read_csv("df_24_COBYLA.csv")
COBYLA_32 = pd.read_csv("df_32_COBYLA.csv")
COBYLA_40 = pd.read_csv("df_40_COBYLA.csv")
COBYLA_48 = pd.read_csv("df_48_COBYLA.csv")

SLSQP_08['method'] = "SLSQP"
SLSQP_16['method'] = "SLSQP"
SLSQP_24['method'] = "SLSQP"
SLSQP_32['method'] = "SLSQP"
SLSQP_40['method'] = "SLSQP"
SLSQP_48['method'] = "SLSQP"
COBYLA_08['method'] = "COBYLA"
COBYLA_16['method'] = "COBYLA"
COBYLA_24['method'] = "COBYLA"
COBYLA_32['method'] = "COBYLA"
COBYLA_40['method'] = "COBYLA"
COBYLA_48['method'] = "COBYLA"
SLSQP_08['model'] = 8
SLSQP_16['model'] = 16
SLSQP_24['model'] = 24
SLSQP_32['model'] = 32
SLSQP_40['model'] = 40
SLSQP_48['model'] = 48
COBYLA_08['model'] = 8
COBYLA_16['model'] = 16
COBYLA_24['model'] = 24
COBYLA_32['model'] = 32
COBYLA_40['model'] = 40
COBYLA_48['model'] = 48

frames = [SLSQP_08, SLSQP_16, SLSQP_24, SLSQP_32, SLSQP_40, SLSQP_48, COBYLA_08, COBYLA_16, COBYLA_24, COBYLA_32, COBYLA_40, COBYLA_48]
result = pd.concat(frames)
result.to_csv("dataframe_output/df_latest.csv")
