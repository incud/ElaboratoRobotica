#!/usr/bin/env python

import rospy

from sensor_msgs.msg import JointState
from std_msgs.msg import Int64

def modify_joint0_value():
    rospy.loginfo("Inserisci il valore del giunto 'joint0': ")
    joint_value = float(raw_input())
    message = JointState()
    message.name.append("joint0")
    message.position.append(joint_value)
    message.velocity.append(0.0)
    return message


def joint_reader(message):
    for i,name in enumerate(message.name):
        if name == "joint0":
            pos = message.position[i]
            rospy.loginfo("Joint0 position: {}".format(pos))
    


def talker():
    # per vedere lo stato dei giunti puoi usare i comandi:
    # rostopic list | rostopic info /joint_states | rostopic echo /joint_states

    rospy.init_node('talker_kinematic_controller', anonymous=True)
    JOINT_STATE_PUBLISHER = rospy.Publisher("move_group/fake_controller_joint_states", JointState, queue_size=1)
    rospy.Subscriber("joint_states", JointState, joint_reader, queue_size=1)
    rate = rospy.Rate(1)
    while not rospy.is_shutdown():
        message = modify_joint0_value()
        JOINT_STATE_PUBLISHER.publish(message)
        rate.sleep()

    
if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
