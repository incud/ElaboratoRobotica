#!/usr/bin/env python

# Dependences: pykdl_utils python-kdl-parser ros-melodic-trac-ik ros-melodic-python-orocos-kdl
# Install trac-ik: apt-get install ros-melodic-trac-ik
# Using trac-ik: https://bitbucket.org/traclabs/trac_ik/src/HEAD/trac_ik_python/
# Install pykdl_utils guide: http://www.programmersought.com/article/1577500905/
# Using pykdl_utils: https://answers.ros.org/question/281272/get-forward-kinematics-wo-tf-service-call-from-urdf-joint-angles-kinetic-python/

import rospy
from sensor_msgs.msg import JointState

from PyInquirer import prompt, print_json, Validator, ValidationError

import gym
from gym import error, spaces, utils
from gym.utils import seeding

import random
import itertools
import numpy as np

from keras.models import Sequential, Model
from keras.layers import Dense, Activation, Flatten, Input, Concatenate
from keras.optimizers import Adam

from rl.agents import DDPGAgent
from rl.policy import EpsGreedyQPolicy
from rl.memory import SequentialMemory
from rl.random import OrnsteinUhlenbeckProcess


from trac_ik_python.trac_ik import IK
from urdf_parser_py.urdf import URDF
from pykdl_utils.kdl_kinematics import KDLKinematics


class RobotMover:

    PUBLISHER_TOPIC = "move_group/fake_controller_joint_states"
    SUBSCRIBER_TOPIC = "joint_states"
    joint_positions = []

    def __init__(self):
        self.pub = rospy.Publisher(self.PUBLISHER_TOPIC, JointState, queue_size=1)
        rospy.Subscriber(self.SUBSCRIBER_TOPIC, JointState, self.reader_callback, queue_size=1)

    def reader_callback(self, message):
        self.joint_positions = []
        for i,name in enumerate(message.name):
            elem = (name, message.position[i])
            self.joint_positions.append(elem)

    def read_joint(self, joint_name):
        return self.joint_positions[joint_name]

    def write_joint(self, joint_name, joint_value):
        message = JointState()
        message.name.append(joint_name)
        message.position.append(joint_value)
        message.velocity.append(0.0)
        self.pub.publish(message)

    def get_joint_positions(self):
        return self.joint_positions

    def get_joint_state(self):
        return list(map(lambda elem: elem[1], self.joint_positions))

    def get_last_link(self):
        if len(self.joint_positions) == 0:
            raise ValueError("Haven't read joint state yet, cannot say how many links does the robot have")
        return "link{}".format(len(self.joint_positions))


class RobotKinematics:

    def __init__(self, base_link=None, end_link=None):
        urdf_str = rospy.get_param('/robot_description')
        print("####################################")
        print(urdf_str)
        self.urdf_tree = URDF.from_xml_string(urdf_str)
        if base_link is None:
            base_link = "link0"
        if end_link is None:
            nlinks = len(self.urdf_tree.link_map.keys())
            end_link = "link{}".format(nlinks - 1)
        print("Link chain goes from {} to {}".format(base_link, end_link))
        self.kdl_kin = KDLKinematics(self.urdf_tree, base_link, end_link)
        self.ik_solver = IK(base_link, end_link, urdf_string=urdf_str)

    def calculate_inverse_kinematics(self, joint_state, x, y, z, rx=0, ry=0, rz=0):
        return self.ik_solver.get_ik(joint_state, x, y, z, rx, ry, rz, 1.0, 1e-8, 1e-8, 1e-8)

    def calculate_inverse_kinematics_rl(self):
        # Deep Deterministic Policy gradients
        # https://blog.floydhub.com/robotic-arm-control-deep-reinforcement-learning/
        pass
        
    def calculate_direct_kinematic(self, joint_state):
        forward_kin_matrix = self.kdl_kin.forward(joint_state)
        x = forward_kin_matrix[0, -1]
        y = forward_kin_matrix[1, -1]
        z = forward_kin_matrix[2, -1]
        return { "x" : x, "y" : y, "z" : z }

    def get_joint_names(self):
        # return self.ik_solver.joint_names
        return self.urdf_tree.joint_map.keys()

    def get_link_names(self):
        # return self.ik_solver.link_names
        return self.urdf_tree.link_map.keys()



class SnakeGym(gym.Env):

    # Spaces: https://ai-mrkogao.github.io/reinforcement%20learning/openaigymtutorial/
    # Own enironment: https://mc.ai/creating-a-custom-openai-gym-environment-for-stock-trading/

    metadata = {'render.modes': ['human']}

    def __init__(self):
        self.N_JOINTS = 0
        self.MOVE_DELTA = 0
        pass        

    def set_environment(self, kinematics, goal, MOVE_DELTA=1e-2):
        self.N_JOINTS = len(kinematics.get_joint_names())
        self.MOVE_DELTA = MOVE_DELTA
        self.action_space = spaces.Discrete(self.N_JOINTS * 2)
        self.joint_limits = np.array(self.N_JOINTS * [np.pi/4])
        self.observation_space = spaces.Box(low=-self.joint_limits, high=self.joint_limits)
        self.kinematics = kinematics
        self.goal = goal
        self.reset()

    def __get_position(self, state):
        position = self.kinematics.calculate_direct_kinematic(self.current_state)
        return np.array([position["x"], position["y"], position["z"] ])

    def __parse_action(self, action):
        joint = action / 2
        direction = action % 2
        if joint >= self.N_JOINTS - 1: raise ValueError("Invalid action")
        return (joint, direction)

    def reset(self):
        self.current_state = np.array(self.N_JOINTS * [0])

    def render(self, mode='human', close=False):
        return "{} : {}".format(self.current_state, self.__get_position(self.current_state))

    def step(self, action):

        joint, direction = self.__parse_action(action)
        next_state = np.copy(self.current_state)
        next_state[joint] += -1 * direction * self.MOVE_DELTA
        if next_state[joint] >  np.pi/4: next_state[joint] =  np.pi/4
        if next_state[joint] < -np.pi/4: next_state[joint] = -np.pi/4

        next_position = self.__get_position(next_state)
        reward = -1 * np.linalg.norm(self.goal - next_position)

        self.current_state = next_state
        return self.current_state, reward, self.done, None


class SnakeRL:

    # https://www.analyticsvidhya.com/blog/2017/01/introduction-to-reinforcement-learning-implementation/
    # https://github.com/stanfordnmbl/osim-rl
    # https://github.com/keras-rl/keras-rl/blob/master/examples/ddpg_pendulum.py

    def __init__(self, env):

        # Get the environment and extract the number of actions.
        np.random.seed(123)
        env.seed(123)
        assert len(env.action_space.shape) == 1
        nb_actions = env.action_space.shape[0]

        # Next, we build a very simple model.
        actor = Sequential()
        actor.add(Flatten(input_shape=(1,) + env.observation_space.shape))
        actor.add(Dense(16))
        actor.add(Activation('relu'))
        actor.add(Dense(16))
        actor.add(Activation('relu'))
        actor.add(Dense(16))
        actor.add(Activation('relu'))
        actor.add(Dense(nb_actions))
        actor.add(Activation('linear'))
        print(actor.summary())

        action_input = Input(shape=(nb_actions,), name='action_input')
        observation_input = Input(shape=(1,) + env.observation_space.shape, name='observation_input')
        flattened_observation = Flatten()(observation_input)
        x = Concatenate()([action_input, flattened_observation])
        x = Dense(32)(x)
        x = Activation('relu')(x)
        x = Dense(32)(x)
        x = Activation('relu')(x)
        x = Dense(32)(x)
        x = Activation('relu')(x)
        x = Dense(1)(x)
        x = Activation('linear')(x)
        critic = Model(inputs=[action_input, observation_input], outputs=x)
        print(critic.summary())

        # Finally, we configure and compile our agent. You can use every built-in Keras optimizer and
        # even the metrics!
        memory = SequentialMemory(limit=100000, window_length=1)
        random_process = OrnsteinUhlenbeckProcess(size=nb_actions, theta=.15, mu=0., sigma=.3)
        agent = DDPGAgent(nb_actions=nb_actions, actor=actor, critic=critic, critic_action_input=action_input,
                        memory=memory, nb_steps_warmup_critic=100, nb_steps_warmup_actor=100,
                        random_process=random_process, gamma=.99, target_model_update=1e-3)
        agent.compile(Adam(lr=.001, clipnorm=1.), metrics=['mae'])

        self.env = env
        self.agent = agent


    def train(self):

        # Okay, now it's time to learn something! We visualize the training here for show, but this
        # slows down training quite a lot. You can always safely abort the training prematurely using
        # Ctrl + C.
        self.agent.fit(self.env, nb_steps=50000, visualize=True, verbose=1, nb_max_episode_steps=200)


    def test(self):
        # Finally, evaluate our algorithm for 5 episodes.
        self.agent.test(self.env, nb_episodes=5, visualize=True, nb_max_episode_steps=200)
    

class Cli:

    class NumberValidator(Validator):
        def validate(self, document):
            try:
                float(document.text)
            except ValueError:
                raise ValidationError(
                    message='Please enter a correct float',
                    cursor_position=len(document.text))  # Move cursor to end

    NEXT_MOVE_SEE_STATE = 'See joint state'
    NEXT_MOVE_DIRECT_KIN = 'Get end-effector position'
    NEXT_MOVE_INVERSE_KIN = 'Move end-effector (TRAC-IK)'
    QUESTION_NEXT_MOVE = [{
        'type': 'list',
        'name': 'move',
        'message': 'What\'s your next move?',
        'choices': [NEXT_MOVE_SEE_STATE, NEXT_MOVE_DIRECT_KIN, NEXT_MOVE_INVERSE_KIN]
    }]

    QUESTION_GET_POSITION = [
        {
            'type': 'input',
            'name': 'x',
            'message': 'X coordinate?',
            'validate': NumberValidator,
            'filter': lambda x: float(x)
        },
        {
            'type': 'input',
            'name': 'y',
            'message': 'Y coordinate?',
            'validate': NumberValidator,
            'filter': lambda x: float(x)
        },
        {
            'type': 'input',
            'name': 'z',
            'message': 'Z coordinate?',
            'validate': NumberValidator,
            'filter': lambda x: float(x)
        }
    ]

    def __init__(self, mover, kin):
        self.mover = mover
        self.kin = kin


    def print_table_row(self, name, value):
        print("{0:>7s} : {1: 1.4f}".format(name, value))


    def ask_for_something(self):

        answer = prompt(self.QUESTION_NEXT_MOVE)

        try:
            move = answer['move']
        except KeyError as e:
            print("Please use arrow keys to choose an action, not the mouse pointer")
            return 

        if move == self.NEXT_MOVE_SEE_STATE:
            for (name, value) in self.mover.get_joint_positions():
                self.print_table_row(name, value)

        elif move == self.NEXT_MOVE_DIRECT_KIN:
            joint_state = self.mover.get_joint_state()
            endeffector_position = self.kin.calculate_direct_kinematic(joint_state)
            self.print_table_row("x", endeffector_position["x"])
            self.print_table_row("y", endeffector_position["y"])
            self.print_table_row("z", endeffector_position["z"])

        elif move == self.NEXT_MOVE_INVERSE_KIN:
            coord = prompt(self.QUESTION_GET_POSITION)
            joint_state = self.mover.get_joint_state()
            new_joint_state = self.kin.calculate_inverse_kinematics(joint_state, coord['x'], coord['y'], coord['z'], 0, 0, 0)
            if new_joint_state is None:
                print("Cannot reach given point")
            else:
                joint_positions = self.mover.get_joint_positions()
                for i in range(0, len(joint_positions)):
                    name = joint_positions[i][0]
                    value = new_joint_state[i]
                    self.mover.write_joint(name, value)
                print("Just assigned new state")

        else:
            raise AssertionError("Cannot understand move: {}".format(move))


if __name__ == '__main__':
    try:
        rospy.init_node('ik_tutorial', anonymous=True)
        mover = RobotMover()
        kin = RobotKinematics()
        app = Cli(mover, kin)
        rate = rospy.Rate(1)
        while not rospy.is_shutdown():
            app.ask_for_something()
            rate.sleep()

    except rospy.ROSInterruptException:
        pass
