### Introduction

---

<span style="float:right;">[[source]](https://github.com/keras-rl/keras-rl/blob/master/rl/agents/sarsa.py#L17)</span>
### SARSAAgent

```python
rl.agents.sarsa.SARSAAgent(model, nb_actions, policy=None, test_policy=None, gamma=0.99, nb_steps_warmup=10, train_interval=1, delta_clip=inf)
```

Write me


---

### References
- [Reinforcement learning: An introduction](http://incompleteideas.net/book/the-book-2nd.html), Sutton and Barto, 2018.
