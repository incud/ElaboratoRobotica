from __future__ import print_function, unicode_literals
from PyInquirer import prompt, print_json, Validator, ValidationError
import os
from datetime import datetime
from xml.etree import ElementTree
from xml.etree.ElementTree import Element, SubElement, Comment, tostring
from xml.dom import minidom

# ========================================================================
# ============================= URDF BUILDER =============================
# ========================================================================
    
SIZE_SCALE = 0.1
DIAMETER_PROPERTY = 'diameter'
LENGTH_PROPERTY = 'length'

def create_property(root, name, value):
    prop = SubElement(root, 'xacro:property', {
        'name' : str(name), 
        'value': str(value)
    })
    return prop


def create_material(root, name, r, g, b):
    material = SubElement(root, 'material', {
        'name' : str(name)
    })
    color = SubElement(material, 'color', {
        'rgba' : "{} {} {} 1".format(r, g, b)
    })
    return material


def create_link(root, name, xyz, length, diameter, material):
    link = SubElement(root, 'link', {
        'name' : str(name)
    })
    visual = SubElement(link, 'visual', {})
    origin = SubElement(visual, 'origin', {
        'xyz': str(xyz)
    })
    geometry = SubElement(visual, 'geometry', {})
    cylinder = SubElement(geometry, 'cylinder', {
        'length' : "${{{}}}".format(LENGTH_PROPERTY),
        'radius': "${{{}/2}}".format(DIAMETER_PROPERTY)
    })
    if material is not None:
        SubElement(visual, 'material', {
            'name' : str(material)
        })
    return link


def create_joint(root, joint_name, parent_link_name, child_link_name, joint_xyz, joint_axis):
    joint = SubElement(root, 'joint', {
        'name': str(joint_name),
        'type': 'revolute'
    })
    parent = SubElement(joint, 'parent', { 'link': str(parent_link_name) })
    child = SubElement(joint, 'child', { 'link': str(child_link_name) })
    axis = SubElement(joint, 'axis', { 'xyz': str(joint_axis) })
    origin = SubElement(joint, 'origin', { 'xyz': str(joint_xyz) })
    limit = SubElement(joint, 'limit', {
        'effort': '100',
        'velocity': '100',
        'lower': '-${pi/4}',
        'upper': '${pi/4}'
    })


def build(pieces, diameter, length):
    root = Element('robot', {
        'name': 'snake',
        'xmlns:xacro' : 'http://ros.org/wiki/xacro'
    })
    create_property(root, DIAMETER_PROPERTY, diameter*SIZE_SCALE)
    create_property(root, LENGTH_PROPERTY, length*SIZE_SCALE)
    create_material(root, 'red', 1, 0, 0)
    create_material(root, 'green', 0, 1, 0)
    create_material(root, 'blue', 0, 0, 1)
    MATERIALS = ['red', 'green', 'blue']
    # create links
    for i in range(0, pieces):
        material = MATERIALS[i % len(MATERIALS)]
        create_link(root, "link{}".format(i), "0 0 ${{{}/2}}".format(LENGTH_PROPERTY), length, diameter, material)
    # create joints
    for i in range(0, pieces-1):
        axis = ['1 0 0', '0 1 0'][i % 2]
        create_joint(root, "joint{}".format(i), "link{}".format(i), "link{}".format(i+1), "0 0 ${{{}}}".format(LENGTH_PROPERTY), axis)

    # pretty printing 
    rough_string = ElementTree.tostring(root, 'utf-8')
    reparsed = minidom.parseString(rough_string)
    pretty = reparsed.toprettyxml(indent="  ")
    return pretty


# ========================================================================
# ============================ USER INTERFACE ============================
# ========================================================================

class NumberValidator(Validator):
    def validate(self, document):
        try:
            if int(document.text) <= 0:
                raise ValueError()
        except ValueError:
            raise ValidationError(
                message='Please enter a correct number, greater than zero',
                cursor_position=len(document.text))  # Move cursor to end

class PathValidator(Validator):
    def validate(self, document):
        try:
            if not os.path.isdir(document.text):
                raise ValueError() 
        except ValueError:
            raise ValidationError(
                message='Please enter an existing path',
                cursor_position=len(document.text))  # Move cursor to end

questions = [
    # {
    #     'type': 'input',
    #     'name': 'directory',
    #     'message': 'In which directory should I save the urdf?',
    #     'validate': PathValidator,
    #     'default': '.'
    # },
    {
        'type': 'input',
        'name': 'pieces',
        'message': 'How many pieces does the shake have?',
        'validate': NumberValidator,
        'filter': lambda x: int(x)
    },
    {
        'type': 'input',
        'name': 'diameter',
        'message': 'How is the diameter of each piece?',
        'validate': NumberValidator,
        'filter': lambda x: int(x)
    },
    {
        'type': 'input',
        'name': 'length',
        'message': 'How long is each piece?',
        'validate': NumberValidator,
        'filter': lambda x: int(x)
    }
]

print("Welcome! Let's start building your XACRO snake-like robot model!")
answers = prompt(questions)
xacro = build(answers['pieces'], answers['diameter'], answers['length'])

timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
filename = "modello-{}.xacro".format(timestamp) 
print("Your file will be saved in the current directory as: {}".format(filename))

fhandle = open(filename,"w+")
fhandle.write(xacro)
fhandle.close()
