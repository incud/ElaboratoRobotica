'use strict'
module.exports = {
  NODE_ENV: '"production"',
  PREFIX_PATH: `"${process.env.PREFIX_PATH}"`
}
