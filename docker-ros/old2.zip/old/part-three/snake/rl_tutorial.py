#!/usr/bin/env python

# Dependences: pykdl_utils python-kdl-parser ros-melodic-trac-ik ros-melodic-python-orocos-kdl
# Install trac-ik: apt-get install ros-melodic-trac-ik
# Using trac-ik: https://bitbucket.org/traclabs/trac_ik/src/HEAD/trac_ik_python/
# Install pykdl_utils guide: http://www.programmersought.com/article/1577500905/
# Using pykdl_utils: https://answers.ros.org/question/281272/get-forward-kinematics-wo-tf-service-call-from-urdf-joint-angles-kinetic-python/

from urdf_parser_py.urdf import URDF
from pykdl_utils.kdl_kinematics import KDLKinematics

from PyInquirer import prompt, print_json, Validator, ValidationError

import gym
from gym import error, spaces, utils
from gym.utils import seeding

import random
import itertools
import numpy as np

from keras.models import Sequential, Model
from keras.layers import Dense, Activation, Flatten, Input, Concatenate
from keras.optimizers import Adam

from rl.agents import DDPGAgent
from rl.policy import EpsGreedyQPolicy
from rl.memory import SequentialMemory
from rl.random import OrnsteinUhlenbeckProcess


from rl.agents.dqn import DQNAgent
from rl.policy import BoltzmannQPolicy

from tensorflow.python.framework.ops import disable_eager_execution

import tensorflow as tf

# Remove AttributeError: Tensor.op is meaningless when eager execution is enabled.
disable_eager_execution()

class RobotKinematics:

    def __init__(self, urdf_str):
        self.urdf_tree = URDF.from_xml_string(urdf_str)
        base_link = "link0"
        nlinks = len(self.urdf_tree.link_map.keys())
        end_link = "link{}".format(nlinks - 1)
        print("Link chain goes from {} to {}".format(base_link, end_link))
        self.kdl_kin = KDLKinematics(self.urdf_tree, base_link, end_link)

    def calculate_inverse_kinematics_rl(self):
        # Deep Deterministic Policy gradients
        # https://blog.floydhub.com/robotic-arm-control-deep-reinforcement-learning/
        pass
        
    def calculate_direct_kinematic(self, joint_state):
        forward_kin_matrix = self.kdl_kin.forward(joint_state)
        x = forward_kin_matrix[0, -1]
        y = forward_kin_matrix[1, -1]
        z = forward_kin_matrix[2, -1]
        return { "x" : x, "y" : y, "z" : z }

    def get_joint_names(self):
        return self.urdf_tree.joint_map.keys()

    def get_link_names(self):
        return self.urdf_tree.link_map.keys()



class SnakeGym(gym.Env):

    class NoInfo:
        def items(self):
            return []

    # Spaces: https://ai-mrkogao.github.io/reinforcement%20learning/openaigymtutorial/
    # Own enironment: https://mc.ai/creating-a-custom-openai-gym-environment-for-stock-trading/

    metadata = {'render.modes': ['human']}

    def __init__(self):
        self.N_JOINTS = 0
        self.MOVE_DELTA = 0
        pass        

    def set_environment(self, kinematics, goal, MOVE_DELTA=1e-2):
        self.N_JOINTS = len(kinematics.get_joint_names())
        self.MOVE_DELTA = MOVE_DELTA
        self.action_space = spaces.Discrete(self.N_JOINTS * 2)
        self.joint_limits = np.array(self.N_JOINTS * [np.pi/4])
        self.observation_space = spaces.Box(low=-self.joint_limits, high=self.joint_limits)
        self.kinematics = kinematics
        self.goal = goal
        self.reset()

    def __get_position(self, state):
        position = self.kinematics.calculate_direct_kinematic(self.current_state)
        return np.array([position["x"], position["y"], position["z"] ])

    def __parse_action(self, action):
        joint = action / 2
        direction = action % 2
        if joint >= self.N_JOINTS: raise ValueError("Invalid action: {} | NJOINTS: {}, joint: {}".format(action, self.N_JOINTS, joint))
        return (joint, direction)

    def reset(self):
        self.current_state = np.array(self.N_JOINTS * [0])
        return self.current_state

    def render(self, mode='human', close=False):
        return "{} : {}".format(self.current_state, self.__get_position(self.current_state))

    def step(self, action):

        joint, direction = self.__parse_action(action)
        next_state = np.copy(self.current_state)
        next_state[joint] += -1 * direction * self.MOVE_DELTA
        if next_state[joint] >  np.pi/4: next_state[joint] =  np.pi/4
        if next_state[joint] < -np.pi/4: next_state[joint] = -np.pi/4

        next_position = self.__get_position(next_state)
        reward = -1 * np.linalg.norm(self.goal - next_position)

        self.current_state = next_state
        self.done = reward > 1e-3
        self.info = SnakeGym.NoInfo()

        return self.current_state, reward, self.done, self.info


class SnakeRL:

    # https://www.analyticsvidhya.com/blog/2017/01/introduction-to-reinforcement-learning-implementation/
    # https://github.com/stanfordnmbl/osim-rl
    # https://github.com/keras-rl/keras-rl/blob/master/examples/ddpg_pendulum.py

    def __init__(self, env):

        # Get the environment and extract the number of actions.
        np.random.seed(123)
        env.seed(123)
        nb_actions = env.action_space.n

        # Next, we build a very simple model.
        model = Sequential()
        model.add(Flatten(input_shape=(1,) + env.observation_space.shape))
        model.add(Dense(16))
        model.add(Activation('relu'))
        model.add(Dense(16))
        model.add(Activation('relu'))
        model.add(Dense(16))
        model.add(Activation('relu'))
        model.add(Dense(nb_actions))
        model.add(Activation('linear'))
        print(model.summary())

        # Finally, we configure and compile our agent. You can use every built-in Keras optimizer and
        # even the metrics!
        memory = SequentialMemory(limit=50000, window_length=1)
        policy = BoltzmannQPolicy()
        dqn = DQNAgent(model=model, nb_actions=nb_actions, memory=memory, nb_steps_warmup=10,
                    target_model_update=1e-2, policy=policy)
        dqn.compile(Adam(lr=1e-3), metrics=['mae'])

        self.env = env
        self.dqn = dqn


    def train(self):

        # Okay, now it's time to learn something! We visualize the training here for show, but this
        # slows down training quite a lot. You can always safely abort the training prematurely using
        # Ctrl + C.
        self.dqn.fit(self.env, nb_steps=50000, visualize=True, verbose=2)


    def test(self):
        # Finally, evaluate our algorithm for 5 episodes.
        self.dqn.test(self.env, nb_episodes=5, visualize=True)
    

if __name__ == '__main__':

    urdf_str = None
    with open('modello.urdf', 'r') as urdf_file:
        urdf_str = urdf_file.read()

    kin = RobotKinematics(urdf_str)

    gym = SnakeGym()
    goal = np.array([1, 2, 3])
    gym.set_environment(kin, goal)

    print("Num GPUs Available: ", len(tf.config.experimental.list_physical_devices('GPU')))

    rl = SnakeRL(gym)
    rl.train()
    rl.test()